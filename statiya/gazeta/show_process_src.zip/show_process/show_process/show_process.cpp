// show_process.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "show_process.h"
#include "windows.h"
#include "iostream"
#include <winsock.h>
#include "tlhelp32.h"
#include <iphlpapi.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#define NAME_CONSOLE "FUCK_YOU"
#endif
#pragma comment(lib, "iphlpapi.lib")

// The one and only application object

CWinApp theApp;

using namespace std;

class hide_procces
{
public:
	bool proverka (CString fname);
	void zaderhka();
	void kill(DWORD pid);
	CString time();
	CString ipadr();
	CString read_conf(CString path);
	HWND GetConsole_hWnd();
	void write_procces();

private:
         int time_1;
		 int kill_1;
		 CString path1,path2;
		 CString format;
		 PROCESSENTRY32 proc;
		 CStringArray filein;
	     CString line_w;
		 HANDLE hSnap,hProcess;
		 typedef CMap<CString, LPCTSTR, DWORD, DWORD> CMyMap;
         CMyMap map;
		 CMyMap::CPair* pCurVal;
		 int i,j;
};

HWND hide_procces::GetConsole_hWnd()
{
	SetConsoleTitle(NAME_CONSOLE);
    HWND hwnd;
    hwnd=FindWindow(0, NAME_CONSOLE);
    if(hwnd==0)
      {
		  return 0;
      }
return hwnd;
}

void hide_procces::kill(DWORD pid)
{
  hProcess = OpenProcess( PROCESS_TERMINATE, FALSE, pid );
  TerminateProcess( hProcess, (DWORD) -1 );
  CloseHandle( hProcess );
  
}
CString hide_procces::read_conf(CString path)
{
  CStdioFile file(path,CFile::modeRead);
  CString line,format;
   while(file.ReadString(line))
      {
       if(line.Find("path_out=")==FALSE)
            {
             line.Delete(0,9);
             path1=line;
	 
  	         }
	  if(line.Find("path_in=")==FALSE)
	         {
	          line.Delete(0,8);
	          path2=line;
		 
  	          }
	 if(line.Find("time=")==FALSE)
	         {
	          line.Delete(0,5);
	          time_1=atoi(line);
	          }
	 if(line.Find("kill=")==FALSE)
	         {
	          line.Delete(0,5);
	          kill_1=atoi(line);
	          }
	  	  
 }
                
      file.Close();
	  time_1=time_1*1000;
      write_procces();
	  return 0;
}
bool hide_procces:: proverka (CString fname)
{
    return CFileFind().FindFile(fname) == TRUE;
}



void hide_procces::zaderhka()
{
	HANDLE h;
    h=CreateEvent(0, true, false, "et");
    WaitForSingleObject(h,time_1);

}

CString hide_procces::time()
{
 CTime ct= CTime::GetCurrentTime();	
 CString date1,date2,date;
 date1.Format("%i.%i.%i",ct.GetDay(),ct.GetDayOfWeek(),ct.GetYear());
 date2.Format("%i:%i:%i",ct.GetHour(),ct.GetMinute(),ct.GetSecond());
 date=date1 + " " + date2;
 return date;
}

CString hide_procces::ipadr()
{
	PIP_ADAPTER_INFO pAdapterInfo;
    PIP_ADAPTER_INFO pAdapter = NULL;
    DWORD dwRetVal = 0;
	CString ipadress;

    pAdapterInfo = (IP_ADAPTER_INFO *) malloc( sizeof(IP_ADAPTER_INFO) );
    ULONG ulOutBufLen = sizeof(IP_ADAPTER_INFO);


if (GetAdaptersInfo( pAdapterInfo, &ulOutBufLen) == ERROR_BUFFER_OVERFLOW) {
  free(pAdapterInfo);
  pAdapterInfo = (IP_ADAPTER_INFO *) malloc (ulOutBufLen); 
}

if ((dwRetVal = GetAdaptersInfo( pAdapterInfo, &ulOutBufLen)) == NO_ERROR) {
  pAdapter = pAdapterInfo;
  while (pAdapter) {
  	  ipadress+=(CString)pAdapter->IpAddressList.IpAddress.String + " ";
     pAdapter = pAdapter->Next;
  }
}

  return ipadress ;
}

void hide_procces::write_procces()
{
	hSnap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
	CStdioFile file1(path2,CFile::modeRead);
	filein.RemoveAll();
	filein.FreeExtra();
	map.RemoveAll();
	
	if(proverka(path1)==FALSE)
	{
	CStdioFile file2(path1, CFile::modeCreate); 
	}
	
	CStdioFile file2(path1, CFile::modeReadWrite);
	file2.SeekToEnd();

	while(file1.ReadString(line_w))
	{
		filein.Add(line_w);
		
	}
	
	if (Process32First(hSnap, &proc))
	{
		map.SetAt(proc.szExeFile,proc.th32ProcessID);
		
		while (Process32Next(hSnap, &proc)) 
		{
		
	     map.SetAt(proc.szExeFile,proc.th32ProcessID);
        
		}
	}
    
	pCurVal= map.PGetFirstAssoc();
	 while (pCurVal != NULL)
	 {	
		for(j=0; j<filein.GetCount(); j++)
		{
			if(pCurVal->key==filein.GetAt(j))
			{
				if(kill_1==1)
				{
					kill(pCurVal->value);
					file2.WriteString("KILL  ");
				}
				format.Format("%s ",time());
				file2.WriteString(format);
				format.Format("%s",ipadr());
				file2.WriteString(format);
				format.Format("%s ",filein.GetAt(j));
				file2.WriteString(format);
				file2.WriteString("\n");
			}
		}
		pCurVal= map.PGetNextAssoc(pCurVal);
	 }

	
 	file1.Close();
	file2.Close();
	zaderhka();
	write_procces();
}

int _tmain(int argc, char* argv[])
{
	int nRetCode = 0;
    
	// initialize MFC and print and error on failure
	if (!AfxWinInit(::GetModuleHandle(NULL), NULL, ::GetCommandLine(), 0))
	{
		// TODO: change error code to suit your needs
		_tprintf(_T("Fatal Error: MFC initialization failed\n"));
		nRetCode = 1;
	}
	else
	{
	FreeConsole();
	hide_procces proc;
	if (AttachConsole(ATTACH_PARENT_PROCESS))
    {
		HWND hwndClosole;
        hwndClosole=proc.GetConsole_hWnd();
        ShowWindow(hwndClosole,SW_HIDE);
      }
		
     if(argc==3)
	 {
		 CString str1,str2,str;
	     str1.Format("%s",argv[1]);
	     str2.Format("%s",argv[2]);
		if(str1=="-c")
		 {
			 proc.read_conf(str2);
		 }
		 else
		 {
			 printf("ERROR: parametry ne verny");
		 }
	     	     
	 }
	 else
	 {
		 printf("ERROR: ne vse vvedeny parametry");

	 }
    	
	}

	return nRetCode;
}
